var chartInit01, chartInit02, chartInit03, chartInit04, chartInit05, chartInit06, chartInit07, chartInit08;

function chart01(id) {
  if (chartInit01) {
    chartInit01.dispose();
    chartInit01 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    title: {
      text: '上/下转数量',
      left: '30%',
      top:"7%",
      textStyle: {
        color: "#fff",
        fontWeight:"normal",
        fontSize: 18 * globalScal,
      },
    },
    tooltip: {
      trigger: 'item',
      formatter: "{a} <br/>{b}: {c} ({d}%)"
    },
    legend: {
      orient: 'horizontal',
      itemGap: 14 * globalScal,
      bottom: "13%",
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "上转",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "下转",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    series: [
      {
        name: '上/下转数量',
        type: 'pie',
        radius: ['0%', '40%'],
        center: ['50%', '46%'],
        avoidLabelOverlap: true,
        itemStyle: {
          borderColor: '#12223a',
          borderWidth: 4* globalScal,
        },
        label: {
          show: true,
          color: "#627da3",
          fontSize: 13,
          formatter: function (params) {
            return "{a|" + params.data.name+Math.round(params.percent) + "%}"
          },
          lineHeight: 18* globalScal,
          rich: {
            a: {
              color: "#fff",
              fontSize: 16* globalScal,
            }
          }
        },
        labelLine: {
          show: true,
          length: 8 * globalScal,
          length2: 8 * globalScal,
          lineStyle: {
            color: '#1e97f5',
          }
        },
        data: [
          {
            name: "上转",
            value: 8,
            itemStyle: {
              color: "#1e97f5"
            }
          },

          {
            name: "下转",
            value: 18,
            itemStyle: {
              color: "#2feaab"
            }
          }
        ]
      }]
  };
  myChart.setOption(option);
  return myChart;
};
function chart02(id) {
  if (chartInit02) {
    chartInit02.dispose();
    chartInit02 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    title: {
      text: '转诊分布',
      left: '35%',
      top:"7%",
      textStyle: {
        color: "#fff",
        fontWeight:"normal",
        fontSize: 18 * globalScal,
      },
    },
    tooltip: {
      trigger: 'item',
      formatter: "{a} <br/>{b}: {c} ({d}%)"
    },
    legend: {
      orient: 'horizontal',
      itemGap: 14 * globalScal,
      bottom: "8%",
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "上转门诊",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "上转住院",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "下转门诊",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "下转住院",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    series: [
      {
        name: '上/下转数量',
        type: 'pie',
        radius: ['0%', '40%'],
        center: ['50%', '46%'],
        avoidLabelOverlap: true,
        itemStyle: {
          borderColor: '#12223a',
          borderWidth: 4* globalScal,
        },
        label: {
          show: false,
          color: "#627da3",
          fontSize: 13,
          formatter: function (params) {
            return "{a|" + params.data.name+Math.round(params.percent) + "%}"
          },
          lineHeight: 18* globalScal,
          rich: {
            a: {
              color: "#fff",
              fontSize: 16* globalScal,
            }
          }
        },
        labelLine: {
          show: true,
          length: 8 * globalScal,
          length2: 8 * globalScal,
          lineStyle: {
            color: '#1e97f5',
          }
        },
        data: [
          {
            name: "上转门诊",
            value: 8,
            itemStyle: {
              color: "#316eef"
            }
          },
          {
            name: "上转住院",
            value: 8,
            itemStyle: {
              color: "#24c8f4"
            }
          },

          {
            name: "下转门诊",
            value: 18,
            itemStyle: {
              color: "#faed61"
            }
          },
          {
            name: "下转住院",
            value: 18,
            itemStyle: {
              color: "#2feaab"
            }
          }
        ]
      }]
  };
  myChart.setOption(option);
  return myChart;
};
function chart03(id) {
  if (chartInit03) {
    chartInit03.dispose();
    chartInit03 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    grid: {
      left: "12%",
      right: "4%",
      bottom: "35%",
      top: "12%"
    },
    xAxis: {
      type: "category",
      boundaryGap: true,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0,
        rotate:35,
        margin:12* globalScal,
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: ["凤凰凤凰社康", "航程航程社康", "河东社康", "凤凰凤凰社康", "航程航程社康", "河东社康", "凤凰凤凰社康", "航程航程社康", "河东社康","航程航程社康" ]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#3b4e65"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0,
        margin:15,
      },
    },
    series: [
      {
        name: "建册数",
        type: "bar",
        barWidth: 16 * globalScal,
        itemStyle: {
          color: "#4d73ee"
        },
        data: [200, 150, 300, 420, 370, 400, 280, 370, 400, 280]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chart04(id) {
  if (chartInit04) {
    chartInit04.dispose();
    chartInit04 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    grid: {
      left: "12%",
      right: "4%",
      bottom: "35%",
      top: "12%"
    },
    xAxis: {
      type: "category",
      boundaryGap: true,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0,
        rotate:35,
        margin:12* globalScal,
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: ["宝安中心医院", "宝安中心医院", "宝安中心医院", "宝安中心医院", "宝安中心医院", "宝安中心医院", "宝安中心医院", "宝安中心医院"]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#3b4e65"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0,
        margin:15,
      },
    },
    series: [
      {
        name: "建册数",
        type: "bar",
        barWidth: 16 * globalScal,
        itemStyle: {
          color: "#3fe3b7"
        },
        data: [200, 150, 300, 420, 370, 400, 280, 370]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chart05(id) {
  if (chartInit05) {
    chartInit05.dispose();
    chartInit05 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    grid: {
      left: "12%",
      right: "4%",
      bottom: "29%",
      top: "13%"
    },
    xAxis: {
      type: "value",
      interval:20,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0,
        margin:18* globalScal,
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#3b4e65"
        }
      },
      splitArea: {
        show: false,
      }
    },
    yAxis: {
      type: "category",
      boundaryGap: false,
      axisTick: {
        show: false
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0,
        margin:15,
      },
      data: ["风湿免疫科","眼耳鼻咽喉科","内分泌科","精神科","儿科"]
    },
    series: [
      {
        name: "建册数",
        type: "bar",
        barWidth: 12 * globalScal,
        itemStyle: {
          color: "#6cb7ec"
        },
        data: [80, 40, 60, 120, 100]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chart06(id) {
  if (chartInit06) {
    chartInit06.dispose();
    chartInit06 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    legend: {
      // show:true,
      itemGap: 20 * globalScal,
      top: "4%",
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "社康转诊",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "医院转诊",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: {
      left: "12%",
      right: "6%",
      bottom: "15%",
      top: "23%"
    },
    xAxis: {
      type: "category",
      boundaryGap: false,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0,
        margin:15,
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: ["1月", "2月", "3月", "4月", "5月", "6月", "7月"]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#405a75"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
    },
    series: [
      {
        name: "社康转诊",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#4d73ee"
        },
        lineStyle: {
          color: '#4d73ee',
          width: 2
        },
        areaStyle: {
          color: "rgba(77,115,238,0.2)"
        },
        data: [500, 500, 500, 620, 770, 820, 680]
      },
      {
        name: "医院转诊",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#3fe3b7"
        },
        lineStyle: {
          color: '#3fe3b7',
          width: 2
        },
        areaStyle: {
          color: "rgba(63,227,183,0.2)"
        },
        data: [400, 350, 400, 520, 570, 500, 480]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chart07(id) {
  if (chartInit07) {
    chartInit07.dispose();
    chartInit07 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    legend: {
      // show:true,
      itemGap: 20 * globalScal,
      top: "4%",
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "社康转诊",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "医院门诊",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: {
      left: "12%",
      right: "6%",
      bottom: "30%",
      top: "23%"
    },
    xAxis: {
      type: "category",
      boundaryGap: true,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0,
        rotate:40,
        margin:15,
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: ["凤凰凤凰社康", "航程航程社康", "河东社康", "凤凰凤凰社康", "航程航程社康", "河东社康", "凤凰凤凰社康", "航程航程社康", "河东社康","航程航程社康" ]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#405a75"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
    },
    series: [
      {
        name: "社康转诊",
        type: "bar",
        stack:"one",
        barWidth:16 * globalScal,
        itemStyle: {
          color: "#4d73ee"
        },
        data: [500, 500, 500, 620, 770, 820, 680,770, 820, 680]
      },
      {
        name: "医院门诊",
        type: "bar",
        stack:"one",
        barWidth:16 * globalScal,
        itemStyle: {
          color: "#3fe3b7"
        },
        data: [400, 350, 400, 520, 570, 500, 480,770, 820, 680]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};

$(function () {
  function chartRest() {

    setTimeout(function () {
      chartInit01 = chart01("chart01");
      chartInit02 = chart02("chart02");
      chartInit03 = chart03("chart03");
      chartInit04 = chart04("chart04");
      chartInit05 = chart05("chart05");
      chartInit06 = chart06("chart06");
      chartInit07 = chart07("chart07");
    }, 10)

  }
  chartRest();
  $(window).resize(chartRest);
});