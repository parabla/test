setHtmlSize();
$(window).resize(function () {
  setHtmlSize();
});
// 轮播
var mySwiper1 = new Swiper('#swiper-container1', {
  //            pagination: '.pagination',
  // autoplay: true,
  loop: false,//无缝滚动
  grabCursor: true,
  paginationClickable: true,
  initialSlide: 0,
  autoplay: {
    delay:5000,
    disableOnInteraction: false,
  },
  on: {
    slideChange: function () {
      $(".mode-02 .top-list li").eq(this.realIndex).addClass("active").siblings().removeClass("active");
    },
  },
});

$(".mode-02 .top-list li").on("click", function () {
  $(this).addClass("active").siblings().removeClass("active");
  var index = $(this).index();
  console.log(index);
  mySwiper1.slideTo(index);
});

var mySwiper2 = new Swiper('#swiper-container2', {
  //            pagination: '.pagination',
  // autoplay: true,
  loop: false,//无缝滚动
  grabCursor: true,
  paginationClickable: true,
  initialSlide: 0,
  autoplay: {
    delay:5000,
    disableOnInteraction: false,
  },
  on: {
    slideChange: function () {
      $(".mode-05 .top-list li").eq(this.realIndex).addClass("active").siblings().removeClass("active");
    },
  },
});
$(".mode-05 .top-list li").on("click", function () {
  $(this).addClass("active").siblings().removeClass("active");
  var index = $(this).index();
  mySwiper2.slideTo(index);
});

var SwiperHealthStatus = new Swiper('.health-status', {
  //loop: true,
  loop: false,//无缝滚动
  grabCursor: true,
  paginationClickable: true,
  initialSlide: 0,
  autoplay: {
    delay:5000,
    disableOnInteraction: false,
  },
  on: {
    slideChange: function (params) {
      if(this.realIndex==2){
        scrollContent();
      }
      $(".mode-04 .tab span").eq(this.realIndex).addClass("active").siblings().removeClass("active");
    },
  },
});


$(".mode-04 .tab span").on("click", function () {
  $(this).addClass("active").siblings().removeClass("active");
  var index = $(this).index();
  SwiperHealthStatus.slideTo(index);
});


function weather() {
  $.ajax({
      type: 'GET',
      url: 'https://www.tianqiapi.com/api/',
      data: 'version=v1&city=深圳&appid=63324343&appsecret=6ZezA8sF',
      dataType: 'JSON',
      error: function () {
          //  alert('网络错误');
          console.log('error-weather');
      },
      success: function (res) {
          // console.log(res);
          var data = res.data[0];
          $('#weather').html('深圳：今天 <img class="img-w" src="https://xuesax.com/tianqiapi/skin/cucumber/' + data.wea_img + '.png" /></span><span>' + data.tem1 + '-' + data.tem2 + '</span>');
      }
  });
};
weather();
function timeFn() {
  var now = new Date();
  var year = now.getFullYear();
  var month = now.getMonth() + 1;
  var day = now.getDate();
  var hour = now.getHours();
  var minute = now.getMinutes();
  // var seconds = now.getSeconds();

  var timeStr = toDouble(hour) + toDouble(minute);
  $(".show-time i").text(year + "年" + month + "月" + day + "日");
  $(".show-time .span1").text(timeStr.charAt(0));
  $(".show-time .span2").text(timeStr.charAt(1));
  $(".show-time .span3").text(timeStr.charAt(2));
  $(".show-time .span4").text(timeStr.charAt(3));
}

function toDouble(i) {
  return i < 10 ? "0" + i : "" + i;
}
timeFn();
setInterval(function () {
  timeFn();
}, 10000);


// 疾病顺位定时
function scrollContent(){
  $(".mode-04 .last-list").css({
    marginTop:'0px',
    transition: 'none'
  });

  setTimeout(function(){
    var Height1 = $(".mode-04 .last-list-box").height();
    console.log(Height1);
    var Height2 = $(".mode-04 .last-list").height();
    console.log(Height2);
    var moveTop = Height1 - Height2;
    console.log(moveTop);
    $(".mode-04 .last-list").css({
      marginTop:moveTop,
      transition: 'all 3.6s linear'
    });
  },800)
 
}

