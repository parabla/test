var chartInit01, chartInit02, chartInit03, chartInit04, chartInit05, chartInit06, chartInit07, chartInit08;


function chart01(id) {
  if (chartInit01) {
    chartInit01.dispose();
    chartInit01 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    legend: {
      // show:true,
      itemGap: 20 * globalScal,
      top: "6%",
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "建册数",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: {
      left: "10%",
      right: "4%",
      bottom: "12%",
      top: "25%"
    },
    xAxis: {
      type: "category",
      boundaryGap: true,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: ["1月", "2月", "3月", "4月", "5月", "6月", "7月"]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#405a75"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
    },
    series: [
      {
        name: "建册数",
        type: "bar",
        barWidth: 16 * globalScal,
        itemStyle: {
          color: "#43e2dc"
        },
        areaStyle: {
          color: "rgba(255,247,34,0.2)"
        },
        data: [200, 150, 300, 420, 370, 400, 280]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chart02(id) {
  if (chartInit02) {
    chartInit02.dispose();
    chartInit02 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    title: {
      text: '产妇年龄分布',
      left: '25%',
      textStyle: {
        color: "#fff",
        fontWeight:"normal",
        fontSize: 18 * globalScal,
      },
    },
    tooltip: {
      trigger: 'item',
      formatter: "{a} <br/>{b}: {c} ({d}%)"
    },
    legend: {
      orient: 'vertical',
      right: "3%",
      itemGap: 14 * globalScal,
      top: "6%",
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "<20",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "20-",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "25-",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "30-",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "35-",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "不详",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    series: [
      {
        name: '产妇年龄分布',
        type: 'pie',
        radius: ['0%', '64%'],
        center: ['40%', '52%'],
        avoidLabelOverlap: true,
        itemStyle: {
          borderColor: '#12223a',
          borderWidth: 2,
        },
        label: {
          show: true,
          color: "#627da3",
          fontSize: 13,
          formatter: function (params) {
            return "{a|" + params.data.value + "}"
          },
          lineHeight: 18,
          rich: {
            a: {
              color: "#fff",
              fontSize: 16
            }
          }
        },
        labelLine: {
          show: true,
          length: 8,
          length2: 12,
          lineStyle: {
            color: '#89919d',
          }
        },
        data: [
          {
            name: "<20",
            value: 12,
            itemStyle: {
              color: "#56bbdc"
            }
          },

          {
            name: "20-",
            value: 12,
            itemStyle: {
              color: "#2aa086"
            }
          },
          {
            name: "25-",
            value: 12,
            itemStyle: {
              color: "#5e57c8"
            }
          },
          {
            name: "30-",
            value: 12,
            itemStyle: {
              color: "#cd9ddd"
            }
          },
          {
            name: "35-",
            value: 12,
            itemStyle: {
              color: "#d37192"
            }
          },
          {
            name: "不详",
            value: 12,
            itemStyle: {
              color: "#e5a797"
            }
          }
        ]
      }]
  };
  myChart.setOption(option);
  return myChart;
};
function chart04(id) {
  if (chartInit04) {
    chartInit04.dispose();
    chartInit04 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    legend: {
      // show:true,
      itemGap: 20 * globalScal,
      top: "6%",
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "分娩量",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: {
      left: "10%",
      right: "4%",
      bottom: "12%",
      top: "25%"
    },
    xAxis: {
      type: "category",
      boundaryGap: true,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: ["1月", "2月", "3月", "4月", "5月", "6月", "7月"]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#405a75"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
    },
    series: [
      {
        name: "分娩量",
        type: "bar",
        barWidth: 16 * globalScal,
        itemStyle: {
          color: "#6c86da"
        },
        areaStyle: {
          color: "rgba(255,247,34,0.2)"
        },
        data: [200, 150, 300, 420, 370, 400, 280]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chart03(id) {
  if (chartInit03) {
    chartInit03.dispose();
    chartInit03 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    title: {
      text: '分娩方式',
      left: '19%',
      textStyle: {
        color: "#fff",
        fontWeight:"normal",
        fontSize: 18 * globalScal,
      },
    },
    tooltip: {
      trigger: 'item',
      formatter: "{a} <br/>{b}: {c} ({d}%)"
    },
    legend: {
      orient: 'vertical',
      right: "6%",
      itemGap: 14 * globalScal,
      top: "6%",
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "顺产",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "剖宫产",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "产钳",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "臀位",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "胎头吸引",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "其他",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    series: [
      {
        name: '半径模式',
        type: 'pie',
        radius: ["30%", "70%"],
        center: ['30%', '55%'],
        roseType: 'radius',
        itemStyle: {
          borderColor: '#12223a',
          borderWidth: 2,
        },
        label: {
          normal: {
            show: false
          },
          emphasis: {
            show: true
          }
        },
        lableLine: {
          normal: {
            show: false
          },
          emphasis: {
            show: true
          }
        },
        data: [
          { value: 28, name: '顺产', itemStyle: { color: "#76bdff" } },
          { value: 15, name: '剖宫产', itemStyle: { color: "#6c86da" } },
          { value: 10, name: '产钳', itemStyle: { color: "#5a5cdd" } },
          { value: 5, name: '臀位', itemStyle: { color: "#a168dd" } },
          { value: 20, name: '胎头吸引', itemStyle: { color: "#d37192" } },
          { value: 15, name: '其他', itemStyle: { color: "#e5a797" } }
        ]
      },]
  };
  myChart.setOption(option);
  return myChart;
};
function chart05(id) {
  if (chartInit05) {
    chartInit05.dispose();
    chartInit05 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    legend: {
      // show:true,
      itemGap: 20 * globalScal,
      top: "6%",
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "出院人次",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "门诊人次",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: {
      left: "13%",
      right: "5%",
      bottom: "12%",
      top: "25%"
    },
    xAxis: {
      type: "category",
      boundaryGap: true,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: ["1月", "2月", "3月", "4月", "5月", "6月", "7月"]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#405a75"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
    },
    series: [
      {
        name: "出院人次",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#40cad6"
        },
        lineStyle: {
          color: '#40cad6',
          width: 2
        },
        areaStyle: {
          color: "rgba(64,202,214,0.2)"
        },
        data: [500, 500, 500, 620, 770, 820, 680]
      },
      {
        name: "门诊人次",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#f3839d"
        },
        lineStyle: {
          color: '#f3839d',
          width: 2
        },
        areaStyle: {
          color: "rgba(243,131,157,0.2)"
        },
        data: [400, 350, 400, 520, 570, 500, 480]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chartLiquidFill01(id, data, color) {
  if (chartInit06) {
    chartInit06.dispose();
    chartInit06 = undefined;
  };
  var myChart = echarts.init(document.getElementById(id));
  var liquidFillData = data / 100;
  var option = {
    title: {
      text: '床位使用情况',
      left: '24%',
      textStyle: {
        color: "#fff",
        fontWeight:"normal",
        fontSize: 18 * globalScal,
      },
    },
    legend: {
      // show:true,
      right:"2%",
      orient: 'horizontal',
      itemGap: 12 * globalScal,
      width:50 * globalScal,
      top: "62%",
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "空床数",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "已使用床位数",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
      ]
    },
    series: [
      {
        name: "已使用",
        type: 'liquidFill',
        center: ['40%', '55%'],
        radius: '48%',
        data: [
          {
            name: "已使用",
            value: liquidFillData
          },
          {
            value: liquidFillData
          }
        ],
        backgroundStyle: {
          color: 'rgba(255,255,255,0)'
        },
        itemStyle: {
          color: 'rgba(64,202,214,.3)',
        },
        label: {
          show: true,
          textStyle: {
            fontSize: 34,
            color: 'rgba(255,255,255,1)'
          },
          formatter: function (params) {
            return "{a|" + params.data.name + "}" + "\n" + "{b|" + parseInt(params.data.value * 100) + "%}"
          },
          lineHeight: 30* globalScal,
          rich: {
            a: {
              fontSize: 18* globalScal,
            },
            b: {
              color:"#43e2dc",
              fontSize: 24* globalScal,
              lineHeight: 36* globalScal,
            }
          }
        },
        outline: {
          show: false
        }
      },
      {
        name: '床位使用情况',
        type: 'pie',
        startAngle:-90,
        radius: ['60%', '74%'],
        center: ['40%', '55%'],
        avoidLabelOverlap: true,
        itemStyle: {
          borderColor: '#12223a',
        },
        label: {
          show: false,
        },
        labelLine: {
          show:false
        },
        data: [
          {
            name: "空床数",
            value: 12,
            itemStyle: {
              color: "rgba(171,100,125,0.3)"
            }
          },
          {
            name: "已使用床位数",
            value: 12,
            itemStyle: {
              color: "#f3839d"
            }
          }
        ]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;

};
function chartLiquidFill02(id) {
  if (chartInit07) {
    chartInit07.dispose();
    chartInit07 = undefined;
  };
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    title: {
      text: '性别比',
      left: '35%',
      textStyle: {
        color: "#fff",
        fontWeight:"normal",
        fontSize: 18 * globalScal,
      },
    },
    series: [
      {
        name: "活产男",
        type: 'liquidFill',
        center: ["20%", "50%"],
        itemStyle: {
          shadowBlur: 0,//去掉暗暗的背景
          color: '#40cad6',
        },
        label: {
          show: true,
          position: ['132%', '92%'],
          formatter: function (params) {
            console.log(params.seriesName);
            return "{a|" + params.seriesName + "}" + "\n" + "{b|" + params.data * 100 + "%}"
          },
          lineHeight: 25 * globalScal,
          rich: {
            a: {
              color: "#40cad6",
              fontSize: 18 * globalScal,
            },
            b: {
              color: "#fff",
              fontSize: 18 * globalScal,
            }
          },
        },
        data: [0.34, 0.32],
        // amplitude: 10,
        radius: '50%',
        outline: {
          show: false
        },
        backgroundStyle: {
          color: 'rgba(255,255,255,0)'
          /* borderColor: '#156ACF',
           borderWidth: 1,
           shadowColor: 'rgba(0, 0, 0, 0.4)',
           shadowBlur: 20*/
        },
        shape: "path://M 102 124.06 a 4 4 0 0 1 -4 -4 v -25 a 3 3 0 0 0 -6 0 v 59.5 a 4.5 4.5 0 0 1 -9 0 v -31.5 a 3 3 0 0 0 -6 0 v 31.5 a 4.5 4.5 0 0 1 -9 0 V 95.06 a 3 3 0 1 0 -6 0 v 25 a 4 4 0 0 1 -8 0 v -30 a 8 8 0 0 1 8 -8 H 98 a 8 8 0 0 1 8 8 v 30 A 4 4 0 0 1 102 124.06 Z m -22 -46 a 14 14 0 1 1 14 -14 A 14 14 0 0 1 80 78.06 Z",
      },
      {
        name: "活产女",
        type: 'liquidFill',
        itemStyle: {
          shadowBlur: 0,//去掉暗暗的背景
          color: '#cd9ddd',
        },
        label: {
          show: true,
          position: ['132%', '92%'],
          formatter: function (params) {
            console.log(params.seriesName);
            return "{a|" + params.seriesName + "}" + "\n" + "{b|" + params.data * 100 + "%}"
          },
          lineHeight: 25 * globalScal,
          rich: {
            a: {
              color: "#40cad6",
              fontSize: 18 * globalScal,
            },
            b: {
              color: "#fff",
              fontSize: 18 * globalScal,
            }
          },
        },
        data: [0.34, 0.32],
        // amplitude: 10,
        radius: '50%',
        center: ["65%", "50%"],
        outline: {
          show: false
        },
        backgroundStyle: {
          color: 'rgba(255,255,255,0)'
          /* borderColor: '#156ACF',
           borderWidth: 1,
           shadowColor: 'rgba(0, 0, 0, 0.4)',
           shadowBlur: 20*/
        },
        shape: "path://M 105 119 c -3.71 0.36 -4.67 -3 -6 -8 s -5 -15 -5 -15 s -0.82 -3 -3 -2 s 2 15 2 15 l 4 15 s 2.22 5 -2 5 H 92 v 25.5 a 4.5 4.5 0 0 1 -9 0 V 129 H 77 v 25.5 a 4.5 4.5 0 0 1 -9 0 V 129 H 65 c -4.22 0 -2 -5 -2 -5 l 4 -15 s 4.18 -14 2 -15 s -3 2 -3 2 s -3.67 10 -5 15 s -2.29 8.36 -6 8 s -2 -6 -2 -6 s 6.07 -19.61 8 -26 s 9 -5 9 -5 H 90 s 7.07 -1.39 9 5 s 8 26 8 26 S 108.71 118.64 105 119 Z M 80 78 A 14 14 0 1 1 94 64 A 14 14 0 0 1 80 78 Z",
      },
    ]
  };
  myChart.setOption(option);
  return myChart;
}

function chart08(id) {
  if (chartInit08) {
    chartInit08.dispose();
    chartInit08 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    legend: {
      // show:true,
      itemGap: 20 * globalScal,
      top: "6%",
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "活产数男",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "活产数女",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: {
      left: "10%",
      right: "4%",
      bottom: "12%",
      top: "25%"
    },
    xAxis: {
      type: "category",
      boundaryGap: true,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: ["1月", "2月", "3月", "4月", "5月", "6月", "7月"]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#405a75"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
    },
    series: [
      {
        name: "活产数男",
        type: "bar",
        barWidth: 12 * globalScal,
        itemStyle: {
          color: "#56bbdc"
        },
        areaStyle: {
          color: "rgba(255,247,34,0.2)"
        },
        data: [200, 150, 300, 420, 370, 400, 280]
      },
      {
        name: "活产数女",
        type: "bar",
        barWidth: 12 * globalScal,
        itemStyle: {
          color: "#cd9ddd"
        },
        areaStyle: {
          color: "rgba(255,247,34,0.2)"
        },
        data: [200, 150, 300, 420, 370, 400, 280]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};


$(function () {
  function chartRest() {


    setTimeout(function () {
      chartInit01 = chart01("chart01");
      chartInit02 = chart02("chart02");
      chartInit03 = chart03("chart03");
      chartInit04 = chart04("chart04");
      chartInit05 = chart05("chart05");
      chartInit06 = chartLiquidFill01("chart06", 47, 'rgba(0,224,211,0.2)');
      chartInit07 = chartLiquidFill02("chart07");
      chartInit08 = chart08("chart08");
    }, 10)

  }
  chartRest();
  $(window).resize(chartRest);
});

//mode-05、mode-06滚动
$(function () {
  function scrollDemo(id) {
    //  function scrollDemo(id){

    let requestAnimFrame = (function () {
      return window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        window.mozRequestAnimationFrame ||
        window.oRequestAnimationFrame ||
        window.msRequestAnimationFrame ||
        function (/* function */ callback, /* DOMElement */ element) {
          window.setTimeout(callback, 1000 / 60);
        };
    })();

    // var speed = 40;

    var $_root = $(id);

    var demo = $_root[0];

    var demo2 = $_root.find(".clone-scroll")[0];

    var demo1 = $_root.find(".scroll-list")[0];

    demo2.innerHTML = demo1.innerHTML;

    var tableBox = $_root.find(".table-box");

    // console.log(tableBox);

    var offset = 0;

    function Marquee() {
      // var contentHeight = $(".tableBox").height();
      // var Height = contentHeight + "px";

      //console.log(demo1.offsetHeight);

      var maxOffset = demo1.offsetHeight;

      offset = offset - 0.3;

      // if (demo.scrollTop >= demo1.offsetHeight) {
      //   demo.scrollTop = 0;
      // } else {
      // demo.scrollTop = demo.scrollTop + 1;
      // tableBox.style.webkitTransform = "translateY(0px,"+height+")";

      if (offset <= 0 - maxOffset) {
        offset = 0;
      }
      tableBox.css({ "transform": "translate3d(0px," + offset + "px,0px)" });
      // }
      requestAnimFrame(Marquee);
    }

    requestAnimFrame(Marquee);
  }
  scrollDemo('#scrollDemo01');
  scrollDemo('#scrollDemo02')
});
