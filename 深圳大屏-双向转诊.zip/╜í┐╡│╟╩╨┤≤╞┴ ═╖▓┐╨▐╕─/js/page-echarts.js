var chartInit01, chartInit02, chartInit03, chartInit04, chartInit05, chartInit06, chartInit07, chartInitWSZS, chartMapInit;


var doctorData = {
  "xAxisData": ["2013", "2014", "2015", "2016", "2017", "2018", "2019"],
  "yAxisData": [
    [5, 6, 5, 4, 3, 5, 6],
    [3, 4, 5, 6, 5, 6, 5]
  ]
};



function echartsDoctorFn(id, data) {
  if (chartInitWSZS) {
    chartInitWSZS.dispose();
    chartInitWSZS = undefined;
  };
  console.log('0');
  var Chartdoctor = echarts.init(document.getElementById(id));
  options = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        // 坐标轴指示器，坐标轴触发有效
        type: "shadow" // 默认为直线，可选为：'line' | 'shadow'
      }
    },
    dataZoom: {
      show: false,
      start: 0,
      end: 100
    },
    legend: {
      data: ["千人医生数", "千人护士数"],
      top: "4%",
      // right: "3%",
      itemHeight: 14 * globalScal,
      itemWidth: 21 * globalScal,
      data: [{
        name: "千人医生数",
        icon: "circle",
        textStyle: {
          fontSize: 16 * globalScal,
          color: "#fff"
        }
      }, {
        name: "千人护士数",
        icon: "circle",
        textStyle: {
          fontSize: 16 * globalScal,
          color: "#fff"
        }
      }]
    },
    grid: {
      left: 8 * globalScal,
      right: 14 * globalScal,
      bottom: 10 * globalScal,
      containLabel: true
    },
    xAxis: {
      type: 'category',
      data: data["xAxisData"],
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      axisTick: {
        show: false
      },
      axisLabel: {
        fontSize: 16 * globalScal,
        color: '#fff'
      }
    },
    yAxis: {
      axisLabel: { // 坐标轴的标签
        show: true, // 是否显示
        inside: false, // 是否朝内
        rotate: 0, // 旋转角度
        margin: 8 * globalScal, // 刻度标签与轴线之间的距离
        color: '#fff', // 默认轴线的颜色
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#fff"
        }
      },
      axisTick: {
        show: false
      },
      splitLine: { // gird 区域中的分割线
        show: true, // 是否显示
        lineStyle: {
          color: '#344e82',
          width: 1,
          type: 'solid'
        }
      }
    },
    series: [
      {
        name: "千人医生数",
        type: "bar",
        data: data.yAxisData[0],
        barWidth: 18 * globalScal,
        itemStyle: {
          normal: {
            color: '#12c695'
          }
        },
        markLine: {
          symbol: ["none", "none"],
          lineStyle: {
            color: "#12c695",
            width:2,
            type: "dashed",
          },
          label: {
            show: false
          },
          data: [
            {
              name: '平均分',
              yAxis: 3.8
            }
          ]
        }
      }, {
        name: "千人护士数",
        type: "bar",
        data: data.yAxisData[1],
        barWidth: 18 * globalScal,
        itemStyle: {
          normal: {
            color: '#4c8fff'
          }
        },
        markLine: {
          symbol: ["none", "none"],
          lineStyle: {
            color: "#4c8fff",
            width:2,
            type: "dashed",
          },
          label: {
            show: false
          },
          data: [
            {
              name: '平均分',
              yAxis: 2.2
            }
          ]
        }
      }
    ]
  };

  Chartdoctor.setOption(options);
  return Chartdoctor;
}


var dataNew = null;
var showNumber = 7; //图表显示的个数
var defaultNumber = 7; //数据少于5个不执行滚动


function resetArr(arr) {
  var len = arr.xAxisData.length;
  if (len <= defaultNumber) {
    return arr;
  } else {
    if (dataNew == null) {
      dataNew = {};
      dataNew.xAxisData = arr.xAxisData.slice(0, showNumber);
      dataNew.yAxisData = [
        arr.yAxisData[0].slice(0, showNumber),
        arr.yAxisData[1].slice(0, showNumber)
      ];
    } else {
      if (showNumber >= len) {
        showNumber = 0;
      }
      dataNew.xAxisData.push(arr.xAxisData[showNumber]);
      dataNew.yAxisData[0].push(arr.yAxisData[0][showNumber]);
      dataNew.yAxisData[1].push(arr.yAxisData[1][showNumber]);
      dataNew.xAxisData.shift();
      dataNew.yAxisData[0].shift();
      dataNew.yAxisData[1].shift();
      showNumber++;
    }
    return dataNew;
  }

}

chartInitWSZS = echartsDoctorFn("doctor-number", resetArr(doctorData));

if (doctorData.xAxisData.length > defaultNumber) {
  setInterval(function () {
    var newdoctorData = resetArr(doctorData);
    chartInitWSZS = echartsDoctorFn("doctor-number", newdoctorData);
  }, 3000)
};


function chart01(id) {
  if (chartInit01) {
    chartInit01.dispose();
    chartInit01 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    legend: {
      // show:true,
      itemGap: 20 * globalScal,
      top: "6%",
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "常住人口",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "户籍人口",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "非户籍人口",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: {
      left: "14%",
      right: "8%",
      bottom: "12%",
      top: "25%"
    },
    xAxis: {
      type: "category",
      boundaryGap: false,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: [2013, 2014, 2015, 2016, 2017, 2018, 2019]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#405a75"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
    },
    series: [
      {
        name: "常住人口",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#00b4ff"
        },
        lineStyle: {
          color: '#00b4ff',
          width: 2
        },
        areaStyle: {
          color: "rgba(0,180,255,0.2)"
        },
        data: [500, 500, 500, 620, 770, 820, 680]
      },
      {
        name: "户籍人口",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#0bda28"
        },
        lineStyle: {
          color: '#0bda28',
          width: 2
        },
        areaStyle: {
          color: "rgba(11,218,40,0.2)"
        },
        data: [400, 350, 400, 520, 570, 500, 480]
      },
      {
        name: "非户籍人口",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#fff722"
        },
        lineStyle: {
          color: '#fff722',
          width: 2
        },
        areaStyle: {
          color: "rgba(255,247,34,0.2)"
        },
        data: [200, 150, 300, 420, 370, 400, 280]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chart02(id) {
  if (chartInit02) {
    chartInit02.dispose();
    chartInit02 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: 'axis',
      axisPointer: {            // 坐标轴指示器，坐标轴触发有效
        type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
      }
    },
    legend: {
      top: "2%",
      left: "46%",
      itemWidth: 13 * globalScal,
      itemHeight: 13 * globalScal,
      data: [
        {
          name: "女",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "男",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: [
      {
        left: '19%',
        right: '45%',
        bottom: '12%',
        top: "15%",
        containLabel: false
      },
      {
        left: '55%',
        right: '6%',
        bottom: '12%',
        top: "15%",
        containLabel: false
      }
    ],
    xAxis: [
      {
        type: 'value',
        inverse: true,
        interval: 100,
        axisTick: {
          show: false
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: "#abdcff"
          }
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: "#405a75",
          }
        },
        axisLabel: {
          fontSize: 16 * globalScal,
          color: '#fff',
        }
      },
      {
        type: 'value',
        gridIndex: 1,
        interval: 100,
        axisTick: {
          show: false
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: "#abdcff"
          }
        },
        axisLabel: {
          fontSize: 16 * globalScal,
          color: '#fff',
        },
        splitLine: {
          show: true,
          lineStyle: {
            color: "#405a75",
          }
        }
      }
    ],
    yAxis: [
      {
        type: 'category',
        // position: "left",
        nameTextStyle: {
          fontSize: 16 * globalScal,
          color: '#fff',
        },
        axisTick: {
          show: false,
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: "#abdcff"
          }
        },
        axisLabel: {
          show: true,
          interval: 0,
          fontSize: 16 * globalScal,
          color: '#fff',
        },
        data: ['0-6岁', '7-12岁', '13-17岁', '18-45岁', '46-60岁', '61-89岁', '90岁以上'],
      },
      {
        type: 'category',
        // position: "left",
        gridIndex: 1,
        interval: 0,
        nameTextStyle: {
          fontSize: 16 * globalScal,
          color: '#fff',
        },
        axisTick: {
          show: false,
        },
        axisLine: {
          show: true,
          lineStyle: {
            color: "#abdcff"
          }
        },
        axisLabel: {
          show: false,
          fontSize: 16 * globalScal,
          color: '#fff',
        },
        data: ['0-6岁', '7-12岁', '13-17岁', '18-45岁', '46-60岁', '61-89岁', '90岁以上'],
      }
    ],
    series: [
      {
        name: '女',
        type: 'bar',
        barWidth: 12 * globalScal,
        barGap: 0,
        itemStyle: {
          color: "#bc3772"
        },
        data: [150, 220, 360, 360, 200, 100, 180]
      },
      {
        name: '男',
        type: 'bar',
        xAxisIndex: 1,
        yAxisIndex: 1,
        barWidth: 12 * globalScal,
        itemStyle: {
          color: "#3774ff"
        },
        data: [100, 220, 360, 360, 200, 200, 180]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chart03(id) {
  if (chartInit03) {
    chartInit03.dispose();
    chartInit03 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    legend: {
      // show:true,
      top: "6%",
      itemGap: 30 * globalScal,
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "优良",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "污染",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: {
      left: "8%",
      right: "4%",
      bottom: "10%",
      top: "25%"
    },
    xAxis: {
      type: "category",
      boundaryGap: false,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: [2013, 2014, 2015, 2016, 2017, 2018, 2019]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#405a75"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
    },
    series: [
      {
        name: "优良",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#0bda28"
        },
        lineStyle: {
          color: '#0bda28',
          width: 2
        },
        areaStyle: {
          color: "rgba(11,218,40,0.2)"
        },
        data: [400, 350, 400, 520, 570, 500, 480]
      },
      {
        name: "污染",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#bccbd2"
        },
        lineStyle: {
          color: '#bccbd2',
          width: 2
        },
        areaStyle: {
          color: "rgba(123,127,169,0.2)"
        },
        data: [500, 500, 500, 620, 770, 820, 680]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chart04(id) {
  if (chartInit04) {
    chartInit04.dispose();
    chartInit04 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    legend: {
      // show:true,
      top: "6%",
      itemGap: 30 * globalScal,
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "优良",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "污染",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: {
      left: "8%",
      right: "4%",
      bottom: "10%",
      top: "25%"
    },
    xAxis: {
      type: "category",
      boundaryGap: false,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: [2013, 2014, 2015, 2016, 2017, 2018, 2019]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#405a75"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
    },
    series: [
      {
        name: "优良",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#0bda28"
        },
        lineStyle: {
          color: '#0bda28',
          width: 2
        },
        areaStyle: {
          color: "rgba(11,218,40,0.2)"
        },
        data: [400, 350, 400, 520, 570, 500, 480]
      },
      {
        name: "污染",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#bccbd2"
        },
        lineStyle: {
          color: '#bccbd2',
          width: 2
        },
        areaStyle: {
          color: "rgba(123,127,169,0.2)"
        },
        data: [500, 500, 500, 620, 770, 820, 680]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chart05(id) {
  if (chartInit05) {
    chartInit05.dispose();
    chartInit05 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    legend: {
      // show:true,
      top: "6%",
      itemGap: 30 * globalScal,
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "优良",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "污染",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: {
      left: "8%",
      right: "4%",
      bottom: "10%",
      top: "25%"
    },
    xAxis: {
      type: "category",
      boundaryGap: false,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: [2013, 2014, 2015, 2016, 2017, 2018, 2019]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#405a75"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
    },
    series: [
      {
        name: "优良",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#0bda28"
        },
        lineStyle: {
          color: '#0bda28',
          width: 2
        },
        areaStyle: {
          color: "rgba(11,218,40,0.2)"
        },
        data: [400, 350, 400, 520, 570, 500, 480]
      },
      {
        name: "污染",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#bccbd2"
        },
        lineStyle: {
          color: '#bccbd2',
          width: 2
        },
        areaStyle: {
          color: "rgba(123,127,169,0.2)"
        },
        data: [500, 500, 500, 620, 770, 820, 680]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chart06(id) {
  if (chartInit06) {
    chartInit06.dispose();
    chartInit06 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    legend: {
      // show:true,
      top: "6%",
      itemGap: 30 * globalScal,
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "优良",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "污染",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: {
      left: "8%",
      right: "4%",
      bottom: "10%",
      top: "25%"
    },
    xAxis: {
      type: "category",
      boundaryGap: false,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: [2013, 2014, 2015, 2016, 2017, 2018, 2019]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#405a75"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
    },
    series: [
      {
        name: "优良",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#0bda28"
        },
        lineStyle: {
          color: '#0bda28',
          width: 2
        },
        areaStyle: {
          color: "rgba(11,218,40,0.2)"
        },
        data: [400, 350, 400, 520, 570, 500, 480]
      },
      {
        name: "污染",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#bccbd2"
        },
        lineStyle: {
          color: '#bccbd2',
          width: 2
        },
        areaStyle: {
          color: "rgba(123,127,169,0.2)"
        },
        data: [500, 500, 500, 620, 770, 820, 680]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};
function chart07(id) {
  if (chartInit07) {
    chartInit07.dispose();
    chartInit07 = undefined;
  }
  var myChart = echarts.init(document.getElementById(id));
  var option = {
    tooltip: {
      trigger: "axis",
      axisPointer: {
        type: "shadow"
      }
    },
    legend: {
      // show:true,
      top: "6%",
      itemGap: 30 * globalScal,
      itemWidth: 14 * globalScal,
      itemHeight: 14 * globalScal,
      data: [
        {
          name: "优良",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        },
        {
          name: "污染",
          icon: "circle",
          textStyle: {
            fontSize: 16 * globalScal,
            color: "#fff"
          }
        }
      ]
    },
    grid: {
      left: "8%",
      right: "4%",
      bottom: "10%",
      top: "25%"
    },
    xAxis: {
      type: "category",
      boundaryGap: false,
      axisTick: {
        show: false
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
      axisLine: {
        show: true,
        lineStyle: {
          color: "#abdcff"
        }
      },
      splitLine: {
        show: false,
      },
      splitArea: {
        show: false,
      },
      data: [2013, 2014, 2015, 2016, 2017, 2018, 2019]
    },
    yAxis: {
      type: "value",
      axisTick: {
        show: false
      },
      axisLine: {
        show: false,
        lineStyle: {
          color: "#bfbfbf"
        }
      },
      splitLine: {
        show: true,
        lineStyle: {
          color: "#405a75"
        }
      },
      axisLabel: {
        show: true,
        color: "#fff",
        fontSize: 16 * globalScal,
        interval: 0
      },
    },
    series: [
      {
        name: "优良",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#0bda28"
        },
        lineStyle: {
          color: '#0bda28',
          width: 2
        },
        areaStyle: {
          color: "rgba(11,218,40,0.2)"
        },
        data: [400, 350, 400, 520, 570, 500, 480]
      },
      {
        name: "污染",
        type: "line",
        symbolSize: 8 * globalScal,
        symbol: "circle",
        itemStyle: {
          color: "#bccbd2"
        },
        lineStyle: {
          color: '#bccbd2',
          width: 2
        },
        areaStyle: {
          color: "rgba(123,127,169,0.2)"
        },
        data: [500, 500, 500, 620, 770, 820, 680]
      }
    ]
  };
  myChart.setOption(option);
  return myChart;
};


function chartMap(id) {

  if (chartMapInit) {
    chartMapInit.dispose();
    chartMapInit = undefined;
  }

  var myChart = echarts.init(document.getElementById(id));
  var option = {
    title: {
      text: "健康指数",
      right: 26* globalScal,
      top: 30* globalScal,
      textStyle: {
        fontSize: 18 * globalScal,
        fontWeight: 'normal',
        color: "#73bdc0"
      }
    },
    visualMap: {
      show: true,
      min: 60,
      max: 100,
      right: 30 * globalScal,
      top: 55 * globalScal,
      // calculable: true,
      text:[100,60],
      align:'right',
      itemWidth: 10 * globalScal,
      textStyle: {
        fontSize: 18 * globalScal,
        color: '#73bdc0'
      },
      //seriesIndex: [0],
      inRange: {
        color: ['#092c85', '#0e58c6', '#2382f8'],// 蓝绿
        symbolSize:4 * globalScal
      }
    },
    series: [
      {
        type: 'map',
        map: 'sz',
        label: {
          show: true,
          textStyle: {
            color: "#fff",
            fontSize: 13.74 * globalScal,
          },
          formatter: function (params) {
            var heart = ""
            if (params.value >= 90) {
              heart = 'heart01';
            } else if (params.value >= 80) {
              heart = 'heart02';
            } else {
              heart = 'heart03';
            }
            //{a|
            return params.name;
          },
          rich: {
            a: {
              width: 66 * globalScal,
              height: 32 * globalScal,
              fontSize: 24 * globalScal,
              color: "#dcfff6",
              margin: [30 * globalScal, 0, 0, -15],
              borderRadius: [16 * globalScal],
              padding: [0, 0, 0, 22 * globalScal],
              backgroundColor: 'rgba(16,63,92,.7)'
            },
            heart01: {
              width: 64 * globalScal,
              height: 32 * globalScal,
              fontSize: 24 * globalScal,
              color: "#dcfff6",
              align: 'left',
              padding: [0, 0, 0, 22 * globalScal],
              backgroundColor: {
                image: 'images/num-icon01.png'
              }
            },
            heart02: {
              width: 64 * globalScal,
              height: 32 * globalScal,
              fontSize: 24 * globalScal,
              color: "#dcfff6",
              align: 'left',
              padding: [0, 0, 0, 22 * globalScal],
              backgroundColor: {
                image: 'images/num-icon02.png'
              }
            },
            heart03: {
              width: 64 * globalScal,
              height: 32 * globalScal,
              fontSize: 24 * globalScal,
              color: "#dcfff6",
              align: 'left',
              padding: [0, 0, 0, 22 * globalScal],

              backgroundColor: {
                image: 'images/num-icon03.png'
              }
            },
          },
        },
        center: [114.183292,
          22.667895],
        roam: false,
        itemStyle: {
          normal: {
            areaColor: '#006d94',
            borderColor: '#8ae2e7',
            borderWidth: 2
          }
        },
        animation: false,
        data: [
          {
            name: "福田区",
            value: 90,
          },
          {
            name: "罗湖区",
            value: 82,
          },
          {
            name: "盐田区",
            value: 92,
          },
          {
            name: "南山区",
            value: 92,
          },
          {
            name: "宝安区",
            value: 85,
          },
          {
            name: "龙岗区",
            value: 95,
          },
          {
            name: "龙华区",
            value: 93,
          },
          {
            name: "坪山区",
            value: 90,
          },
          {
            name: "光明区",
            value: 90,
          },
          {
            name: "大鹏新区",
            value: 75
          },
        ]
      },
    ]

  };
  myChart.setOption(option);
  return myChart;
};

$(function () {
  function chartRest() {


    setTimeout(function(){
      chartInit01 = chart01("chart01");
      chartInit02 = chart02("chart02");
      chartInit03 = chart03("chart03");
      chartInit04 = chart04("chart04");
      chartInit05 = chart05("chart05");
      chartInit06 = chart06("chart06");
      chartInit07 = chart07("chart07");
      chartMapInit = chartMap('chartMap');
      chartInitWSZS = echartsDoctorFn("doctor-number", resetArr(doctorData));
    },10)
    
  }
  chartRest();
  $(window).resize(chartRest);
});
