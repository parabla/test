
var globalScal=1;
function setHtmlSize() {
    var defaultWidth = 1866;
    var defaultFontSize = 100;
    var wd = $(window).width();
    var fontSize;
    globalScal=wd / defaultWidth;
    if (wd > defaultWidth) {
        fontSize = defaultFontSize;
    } else {
        fontSize = (wd / defaultWidth) * defaultFontSize;
    }
    $('html').css('font-size', fontSize + 'px');
}

