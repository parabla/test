$(".menu-list .f-item").click(function(){
  $(this).addClass("active").siblings().removeClass("active");
})
$(".menu-list .sub-nav-box li").click(function(){
  $(this).addClass("active").siblings().removeClass("active");
})